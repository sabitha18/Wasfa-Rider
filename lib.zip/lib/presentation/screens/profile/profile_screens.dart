import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:wasfa_rider/core/theme/app_theme.dart';
import 'package:wasfa_rider/data/models/models.dart';
import 'package:wasfa_rider/presentation/viewmodels/app_viewmodel.dart';
import 'package:wasfa_rider/presentation/viewmodels/orders_viewmodel.dart';
import 'package:wasfa_rider/presentation/widgets/shared_widgets.dart';

// ── PROFILE SCREEN ─────────────────────────────────────────────
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.onTabChange, required this.onOpenHistory, required this.onLogout});
  final ValueChanged<String> onTabChange;
  final VoidCallback onOpenHistory, onLogout;

  @override
  Widget build(BuildContext context) {
    final appVM = context.watch<AppViewModel>();
    final ordersVM = context.watch<OrdersViewModel>();
    final driver = appVM.driver;
    if (driver == null) return const Scaffold();

    return Scaffold(
      body: Column(children: [
        // Header
        Container(
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 20, left: 24, right: 24, bottom: 24),
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [WTheme.navy, Color(0xFF04527F)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          ),
          child: Column(children: [
            // Avatar
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [WTheme.sky, WTheme.aqua]),
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: WTheme.sky.withOpacity(0.4), blurRadius: 16)],
              ),
              child: Center(child: Text(driver.avatarInitials,
                style: GoogleFonts.dmSans(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 24))),
            ),
            const SizedBox(height: 12),
            Text(driver.name, style: GoogleFonts.dmSans(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20)),
            Text(driver.phone, style: GoogleFonts.dmMono(color: Colors.white60, fontSize: 13)),
            const SizedBox(height: 16),
            // Stats row
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _Stat('Today', '${driver.todayEarnings.toStringAsFixed(3)} KD'),
              _Stat('Deliveries', '${driver.deliveriesToday}'),
              _Stat('Rating', '⭐ ${driver.rating}'),
            ]),
          ]),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Vehicle info
              WCard(child: Row(children: [
                const Text('🏍', style: TextStyle(fontSize: 28)),
                const SizedBox(width: 14),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(driver.vehicleType.name.toUpperCase(), style: GoogleFonts.dmSans(fontSize: 10, fontWeight: FontWeight.w800, color: WTheme.muted, letterSpacing: 0.5)),
                  Text(driver.plateNumber.isNotEmpty ? driver.plateNumber : '—', style: GoogleFonts.dmMono(fontSize: 16, fontWeight: FontWeight.w700, color: WTheme.navy)),
                ]),
              ])),
              // Menu items
              _MenuItem(emoji: '📋', label: 'Delivery History', onTap: onOpenHistory),
              _MenuItem(emoji: '💰', label: 'Earnings', onTap: () {}),
              _MenuItem(emoji: '⚙️', label: 'Settings', onTap: () {}),
              _MenuItem(emoji: '❓', label: 'Help & Support', onTap: () {}),
              const SizedBox(height: 8),
              _MenuItem(emoji: '🚪', label: 'Logout', onTap: onLogout, color: WTheme.err),
            ],
          ),
        ),
        RiderBottomNav(current: 'profile', onChanged: onTabChange),
      ]),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value);
  final String label, value;

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(label, style: GoogleFonts.dmSans(color: Colors.white60, fontSize: 11)),
      Text(value, style: GoogleFonts.dmSans(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
    ]);
  }
}

class _MenuItem extends StatelessWidget {
  const _MenuItem({required this.emoji, required this.label, required this.onTap, this.color});
  final String emoji, label;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: WTheme.cloud),
        ),
        child: Row(children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: GoogleFonts.dmSans(fontWeight: FontWeight.w700, fontSize: 14, color: color ?? WTheme.navy))),
          Icon(Icons.chevron_right, color: color ?? WTheme.muted, size: 20),
        ]),
      ),
    );
  }
}

// ── HISTORY SCREEN ─────────────────────────────────────────────
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key, required this.onBack});
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final ordersVM = context.watch<OrdersViewModel>();
    final done = ordersVM.orders.where((o) =>
      o.status == OrderStatus.done || o.status == OrderStatus.failed
    ).toList();

    return Scaffold(
      body: Column(children: [
        Container(
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 10, left: 16, right: 16, bottom: 14),
          decoration: BoxDecoration(gradient: LinearGradient(colors: [WTheme.navy, Color(0xFF04527F)])),
          child: Row(children: [
            GestureDetector(
              onTap: onBack,
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 16),
              ),
            ),
            const SizedBox(width: 14),
            Text('Delivery History', style: GoogleFonts.dmSans(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)),
          ]),
        ),
        Expanded(
          child: done.isEmpty
              ? Center(child: Text('No deliveries yet', style: GoogleFonts.dmSans(color: WTheme.muted, fontSize: 15)))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: done.length,
                  itemBuilder: (ctx, i) {
                    final o = done[i];
                    final failed = o.status == OrderStatus.failed;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: WTheme.cloud),
                      ),
                      child: Row(children: [
                        Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(
                            color: failed ? WTheme.err.withOpacity(0.12) : WTheme.ok.withOpacity(0.12),
                            shape: BoxShape.circle,
                          ),
                          child: Center(child: Text(failed ? '🚫' : '✓', style: TextStyle(fontSize: 18, color: failed ? WTheme.err : WTheme.ok))),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(o.patient, style: GoogleFonts.dmSans(fontWeight: FontWeight.w800, fontSize: 14, color: WTheme.navy)),
                          Text('${o.id} · ${o.addr1}', style: GoogleFonts.dmSans(fontSize: 11, color: WTheme.muted)),
                          if (o.deliveredAt != null)
                            Text('Delivered at ${_fmt(o.deliveredAt!)}', style: GoogleFonts.dmSans(fontSize: 11, color: WTheme.ok, fontWeight: FontWeight.w600)),
                        ])),
                        Text('${o.total.toStringAsFixed(3)} KD', style: GoogleFonts.dmSans(fontWeight: FontWeight.w800, fontSize: 14, color: WTheme.navy)),
                      ]),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  String _fmt(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}
