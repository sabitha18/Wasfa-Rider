import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wasfa_rider/core/theme/app_theme.dart';
import 'package:wasfa_rider/data/models/models.dart';
import 'package:wasfa_rider/presentation/viewmodels/orders_viewmodel.dart';
import 'package:wasfa_rider/presentation/widgets/shared_widgets.dart';

class OrderDetailScreen extends StatelessWidget {
  const OrderDetailScreen({
    super.key,
    required this.orderId,
    required this.onBack,
    required this.onArrive,
    required this.onCantDeliver,
    required this.onTransitionState,
    required this.onMultiPickup,
  });
  final String orderId;
  final VoidCallback onBack, onArrive, onCantDeliver, onMultiPickup;
  final void Function(String id, DriverState state) onTransitionState;

  @override
  Widget build(BuildContext context) {
    final vm    = context.watch<OrdersViewModel>();
    final order = vm.findById(orderId);
    if (order == null) return const Scaffold(body: Center(child: Text('Order not found')));
    final allCount = vm.orders.where((o) => [
      OrderStatus.active, OrderStatus.next, OrderStatus.later, OrderStatus.batchPending
    ].contains(o.status)).length;

    return Scaffold(
      backgroundColor: WTheme.blush,
      body: Column(children: [
        // ── Blue gradient hero ────────────────────────────────
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [Color(0xFF023B60), Color(0xFF1E9CD7)],
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Row 1: back + STOP X OF Y + countdown
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  GestureDetector(
                    onTap: onBack,
                    child: Container(
                      width: 34, height: 34,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: const Center(child: Text('‹', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700))),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: WTheme.aqua, borderRadius: BorderRadius.circular(999)),
                    child: Text('STOP ${order.stopNumber} OF $allCount',
                        style: GoogleFonts.dmSans(color: WTheme.navy, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 0.3)),
                  ),
                  if (order.status != OrderStatus.done && order.status != OrderStatus.failed)
                    SlaCountdown(order: order, size: 'm')
                  else
                    const SizedBox(width: 34),
                ]),
                const SizedBox(height: 10),
                // Row 2: order ID + total
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text('#${order.id}', style: GoogleFonts.dmSans(
                          color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                      RichText(text: TextSpan(children: [
                        TextSpan(text: order.total.toStringAsFixed(3),
                            style: GoogleFonts.dmSans(color: Colors.white, fontSize: 22,
                                fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                        TextSpan(text: ' KD', style: GoogleFonts.dmSans(
                            color: Colors.white.withOpacity(0.8), fontSize: 12, fontWeight: FontWeight.w600)),
                      ])),
                    ]),
                const SizedBox(height: 4),
                // Date
                Text('📅 ${_fmtDateLong(order.createdAt)}',
                    style: GoogleFonts.dmSans(color: Colors.white.withOpacity(0.8), fontSize: 11, fontWeight: FontWeight.w600)),
                const SizedBox(height: 10),
                // Status pills row
                Wrap(spacing: 6, runSpacing: 6, children: [
                  _HeroPill(text: '${_driverIcon(order.driverState)} ${_driverLabel(order.driverState)}'),
                  _HeroPill(
                    text: order.paid ? '✓ PAID' : '${order.payMethod.name.toUpperCase()} · NOT PAID',
                    color: order.paid ? WTheme.ok.withOpacity(0.30) : WTheme.warn.withOpacity(0.30),
                  ),
                  _HeroPill(text: '📍 ${order.distanceKm} km · ⏱ ${order.etaMin} min'),
                  _HeroPill(text: '📦 ${order.items.length} item${order.items.length != 1 ? "s" : ""}'),
                ]),
              ]),
            ),
          ),
        ),
        // ── Scrollable body ───────────────────────────────────
        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: Column(children: [
            // Customer note
            if (order.customerNote != null) _NoteCard(note: order.customerNote!),
            // Items card
            _ItemsCard(order: order),
            // Customer details card
            _CustomerCard(order: order),
            // Building photos block (before total — matches HTML)
            _BuildingPhotosBlock(order: order),
            // Total to collect card
            _TotalCard(order: order),
            // Send payment link / already paid
            if (!order.paid)
              _whatsappBtn(order, context)
            else
              _paidBanner(),
            // Big payment status block (bottom of scroll)
            _BigPaymentStatus(order: order),
            const SizedBox(height: 14),
          ]),
        )),
        // ── Bottom action bar ─────────────────────────────────
        Container(
          color: WTheme.blush,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
          child: Column(children: [
            _DriverActionBar(
              order: order,
              onTransitionState: onTransitionState,
              onArrive: onArrive,
              onMultiPickup: onMultiPickup,
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: onCantDeliver,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: WTheme.err, width: 1.5),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(child: Text("🚫 Can't deliver — failed",
                    style: GoogleFonts.dmSans(color: WTheme.err, fontSize: 13, fontWeight: FontWeight.w700))),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _whatsappBtn(Order order, BuildContext context) => GestureDetector(
    onTap: () async {
      final msg = Uri.encodeComponent('Hi ${order.patient}, your payment link for WASFA order #${order.id}: pay.wasfakw.com/o/${order.id} · ${order.total.toStringAsFixed(3)} KD');
      final url = 'https://wa.me/${order.phone.replaceAll(RegExp(r'\D'), '')}?text=$msg';
      if (await canLaunchUrl(Uri.parse(url))) launchUrl(Uri.parse(url));
    },
    child: Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF25D366), Color(0xFF128C7E)]),
        boxShadow: [BoxShadow(color: const Color(0xFF25D366).withOpacity(0.4), blurRadius: 28, offset: const Offset(0, 12))],
      ),
      child: Center(child: Text('🔗 Send payment link to patient via WhatsApp',
          style: GoogleFonts.dmSans(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800))),
    ),
  );

  Widget _paidBanner() => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: WTheme.ok.withOpacity(0.10),
      border: Border.all(color: WTheme.ok, width: 1.5, style: BorderStyle.solid),
    ),
    child: Center(child: Text('✓ This order is already paid — no collection needed',
        style: GoogleFonts.dmSans(color: WTheme.ok, fontSize: 13, fontWeight: FontWeight.w700))),
  );

  static String _fmtDateLong(DateTime d) {
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final h = d.hour > 12 ? d.hour - 12 : (d.hour == 0 ? 12 : d.hour);
    final ampm = d.hour < 12 ? 'AM' : 'PM';
    return '${months[d.month-1]} ${d.day}, $h:${d.minute.toString().padLeft(2,'0')} $ampm';
  }

  static String _driverLabel(DriverState s) => switch (s) {
    DriverState.pending    => 'Pending',
    DriverState.collecting => 'Collecting',
    DriverState.pickedUp   => 'Picked up',
    DriverState.onMyWay    => 'On my way',
    DriverState.delivered  => 'Delivered',
    DriverState.failed     => 'Failed',
  };

  static String _driverIcon(DriverState s) => switch (s) {
    DriverState.pending    => '⏳',
    DriverState.collecting => '🛒',
    DriverState.pickedUp   => '📦',
    DriverState.onMyWay    => '🛵',
    DriverState.delivered  => '✓',
    DriverState.failed     => '🚫',
  };
}

// ── Hero pill ──────────────────────────────────────────────────
class _HeroPill extends StatelessWidget {
  const _HeroPill({required this.text, this.color});
  final String text;
  final Color? color;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: color ?? Colors.white.withOpacity(0.18),
      borderRadius: BorderRadius.circular(999),
    ),
    child: Text(text, style: GoogleFonts.dmSans(
        color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.3)),
  );
}

// ── Customer note ──────────────────────────────────────────────
class _NoteCard extends StatelessWidget {
  const _NoteCard({required this.note});
  final String note;

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: [WTheme.warn.withOpacity(0.13), WTheme.warn.withOpacity(0.06)],
          begin: Alignment.topLeft, end: Alignment.bottomRight),
      border: Border.all(color: WTheme.warn, width: 2),
      boxShadow: [BoxShadow(color: WTheme.warn.withOpacity(0.35), blurRadius: 18, offset: const Offset(0, 6))],
    ),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        width: 38, height: 38,
        decoration: BoxDecoration(color: WTheme.warn, borderRadius: BorderRadius.circular(10)),
        child: const Center(child: Text('📝', style: TextStyle(fontSize: 20))),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('⚠ CUSTOMER NOTE — PLEASE READ', style: GoogleFonts.dmSans(
            fontSize: 10, fontWeight: FontWeight.w800, color: const Color(0xFF8A5A0A), letterSpacing: 0.8)),
        const SizedBox(height: 4),
        Text(note, style: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w700, color: WTheme.ink, height: 1.4)),
      ])),
    ]),
  );
}

// ── Items card ─────────────────────────────────────────────────
class _ItemsCard extends StatelessWidget {
  const _ItemsCard({required this.order});
  final Order order;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white,
      boxShadow: [BoxShadow(color: WTheme.navy.withOpacity(0.10), blurRadius: 30, offset: const Offset(0, 12))],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('📦 ITEMS (${order.items.length})', style: GoogleFonts.dmSans(
            fontSize: 11, fontWeight: FontWeight.w700, color: WTheme.muted, letterSpacing: 0.5)),
        if (order.multiPharmacy)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
            decoration: BoxDecoration(color: WTheme.aqua.withOpacity(0.18),
                borderRadius: BorderRadius.circular(999)),
            child: Text('🏥 ${order.pickups.length} pharmacies',
                style: GoogleFonts.dmSans(fontSize: 10, fontWeight: FontWeight.w800,
                    color: const Color(0xFF2A9BBC))),
          ),
      ]),
      const SizedBox(height: 12),
      ...order.items.map((item) => _RichItemCard(item: item, showPharmacy: order.multiPharmacy)),
    ]),
  );
}

// ── Rich item card (matches HTML's RichItemCard) ───────────────
class _RichItemCard extends StatefulWidget {
  const _RichItemCard({required this.item, this.showPharmacy = false});
  final OrderItem item;
  final bool showPharmacy;

  @override
  State<_RichItemCard> createState() => _RichItemCardState();
}

class _RichItemCardState extends State<_RichItemCard> {
  void _showLightbox() {
    final item = widget.item;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (ctx) => GestureDetector(
        onTap: () => Navigator.of(ctx).pop(),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Stack(children: [
            // ×  close button — top right, matches HTML
            Positioned(
              top: MediaQuery.of(ctx).padding.top + 20,
              right: 20,
              child: GestureDetector(
                onTap: () => Navigator.of(ctx).pop(),
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.20),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.5),
                  ),
                  child: const Center(child: Text('×', style: TextStyle(
                      color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800))),
                ),
              ),
            ),
            // Content — centred, zoom animation via scale
            Center(child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 80, 24, 40),
              child: GestureDetector(
                onTap: () {}, // prevent tap-through
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  // Big image box — square aspect ratio matches HTML
                  Container(
                    width: double.infinity,
                    height: 280,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                        colors: [item.color, item.color.withOpacity(0.55)],
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(color: item.color.withOpacity(0.67), blurRadius: 80, offset: const Offset(0, 30)),
                        BoxShadow(color: Colors.white.withOpacity(0.12), blurRadius: 0, spreadRadius: 1),
                      ],
                    ),
                    child: Stack(children: [
                      const Center(child: Text('💊', style: TextStyle(fontSize: 120, height: 1))),
                      Positioned(top: 14, right: 14, child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: WTheme.rose,
                          borderRadius: BorderRadius.circular(999),
                          boxShadow: [BoxShadow(color: WTheme.rose.withOpacity(0.4), blurRadius: 14, offset: const Offset(0, 6))],
                        ),
                        child: Text(item.tag, style: GoogleFonts.dmSans(
                            color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 0.4)),
                      )),
                    ]),
                  ),
                  const SizedBox(height: 16),
                  // Info card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 50, offset: Offset(0, 20))],
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(item.name, style: GoogleFonts.dmSans(fontWeight: FontWeight.w800,
                          color: WTheme.navy, fontSize: 17, letterSpacing: -0.2, height: 1.3)),
                      const SizedBox(height: 12),
                      Container(height: 1, color: WTheme.cloud),
                      const SizedBox(height: 12),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        RichText(text: TextSpan(children: [
                          TextSpan(text: item.price.toStringAsFixed(3),
                              style: GoogleFonts.dmSans(fontWeight: FontWeight.w800,
                                  color: WTheme.rose, fontSize: 22, letterSpacing: -0.4)),
                          TextSpan(text: ' KD', style: GoogleFonts.dmSans(
                              fontSize: 12, color: WTheme.muted, fontWeight: FontWeight.w700)),
                        ])),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                                begin: Alignment.topLeft, end: Alignment.bottomRight,
                                colors: [Color(0xFF023B60), Color(0xFF04527F)]),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [BoxShadow(color: WTheme.navy.withOpacity(0.4),
                                blurRadius: 14, offset: const Offset(0, 6))],
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.baseline,
                              textBaseline: TextBaseline.alphabetic, children: [
                                Text('QTY', style: GoogleFonts.dmSans(
                                    color: Colors.white.withOpacity(0.75), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.4)),
                                const SizedBox(width: 6),
                                Text('×${item.qty}', style: GoogleFonts.dmSans(
                                    color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                              ]),
                        ),
                      ]),
                      if (item.pharmacy != null) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: WTheme.blush,
                            borderRadius: BorderRadius.circular(10),
                            border: Border(left: BorderSide(color: WTheme.aqua, width: 3)),
                          ),
                          child: RichText(text: TextSpan(
                            style: GoogleFonts.dmSans(fontSize: 11, color: WTheme.muted, fontWeight: FontWeight.w700),
                            children: [
                              const TextSpan(text: '🏥 From: '),
                              TextSpan(text: item.pharmacy!, style: TextStyle(
                                  color: WTheme.navy, fontWeight: FontWeight.w800)),
                            ],
                          )),
                        ),
                      ],
                    ]),
                  ),
                ]),
              ),
            )),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
          border: Border.all(color: WTheme.cloud, width: 1.5)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Color image box — tap to open lightbox
        GestureDetector(
          onTap: _showLightbox,
          child: Padding(
            padding: const EdgeInsets.only(top: 4, right: 4), // room for badge overflow
            child: SizedBox(
              width: 64, height: 64,
              child: Stack(clipBehavior: Clip.none, children: [
                Container(
                  width: 64, height: 64,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                        colors: [item.color, item.color.withOpacity(0.55)]),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: item.color.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 4))],
                  ),
                  child: const Center(child: Text('💊', style: TextStyle(fontSize: 28))),
                ),
                // Tag badge
                Positioned(top: -4, right: -4, child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(color: WTheme.rose, borderRadius: BorderRadius.circular(6),
                      boxShadow: [BoxShadow(color: WTheme.rose.withOpacity(0.5), blurRadius: 6, offset: const Offset(0, 2))]),
                  child: Text(item.tag, style: GoogleFonts.dmSans(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: 0.3)),
                )),
                // Zoom affordance
                Positioned(bottom: 3, right: 3, child: Container(
                  width: 18, height: 18,
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.45), shape: BoxShape.circle),
                  child: const Center(child: Text('⤢', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800))),
                )),
              ]),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.name, style: GoogleFonts.dmSans(fontWeight: FontWeight.w700, color: WTheme.navy, fontSize: 13, height: 1.3)),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            RichText(text: TextSpan(children: [
              TextSpan(text: item.price.toStringAsFixed(3), style: GoogleFonts.dmSans(fontWeight: FontWeight.w800, color: WTheme.rose, fontSize: 15)),
              TextSpan(text: ' KD', style: GoogleFonts.dmSans(fontSize: 10, color: WTheme.muted, fontWeight: FontWeight.w600)),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                      colors: [Color(0xFF023B60), Color(0xFF04527F)]),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [BoxShadow(color: WTheme.navy.withOpacity(0.33), blurRadius: 10, offset: const Offset(0, 4))]),
              child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic, children: [
                    Text('QTY', style: GoogleFonts.dmSans(color: Colors.white.withOpacity(0.7), fontSize: 11, fontWeight: FontWeight.w700)),
                    const SizedBox(width: 4),
                    Text('×${item.qty}', style: GoogleFonts.dmSans(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                  ]),
            ),
          ]),
          if (widget.showPharmacy && item.pharmacy != null) ...[
            const SizedBox(height: 4),
            Text('🏥 Seller: ${item.pharmacy}', style: GoogleFonts.dmSans(fontSize: 10, color: WTheme.muted, fontWeight: FontWeight.w600)),
          ],
        ])),
      ]),
    );
  }
}

// ── Customer details card ──────────────────────────────────────
class _CustomerCard extends StatelessWidget {
  const _CustomerCard({required this.order});
  final Order order;

  @override
  Widget build(BuildContext context) {
    final initials = order.patient.split(' ').map((n) => n.isNotEmpty ? n[0] : '').take(2).join();
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: WTheme.navy.withOpacity(0.10), blurRadius: 30, offset: const Offset(0, 12))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('👤 CUSTOMER DETAILS', style: GoogleFonts.dmSans(
            fontSize: 11, fontWeight: FontWeight.w700, color: WTheme.muted, letterSpacing: 0.5)),
        const SizedBox(height: 12),
        // Patient row
        Row(children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(color: WTheme.blush, borderRadius: BorderRadius.circular(14)),
            child: Center(child: Text(initials, style: GoogleFonts.dmSans(
                color: WTheme.rose, fontWeight: FontWeight.w800, fontSize: 16))),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(order.patient, style: GoogleFonts.dmSans(fontWeight: FontWeight.w700, color: WTheme.navy, fontSize: 15)),
            Text('${order.phone} · masked', style: GoogleFonts.dmSans(fontSize: 12, color: WTheme.muted)),
          ])),
        ]),
        const SizedBox(height: 12),
        // Address block
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: WTheme.cloud, borderRadius: BorderRadius.circular(0)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('📍', style: TextStyle(color: WTheme.rose, fontSize: 16)),
            const SizedBox(width: 8),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(order.addr1, style: GoogleFonts.dmSans(fontWeight: FontWeight.w700, color: WTheme.navy, fontSize: 13, height: 1.4)),
              Text(order.addr2, style: GoogleFonts.dmSans(fontSize: 12, color: WTheme.muted)),
              if (order.landmark != null)
                Text('Landmark: ${order.landmark}', style: GoogleFonts.dmSans(fontSize: 11, color: WTheme.muted, fontStyle: FontStyle.italic)),
            ])),
          ]),
        ),
        const SizedBox(height: 12),
        // 2×2 action grid
        GridView.count(
          crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 4.5,
          children: [
            _ContactBtn(label: '📞 Call', bg: WTheme.ok, fg: Colors.white,
                onTap: () => _launch('tel:${order.phone.replaceAll(RegExp(r'\s'), '')}')),
            _ContactBtn(label: '💬 WhatsApp', bg: const Color(0xFF25D366), fg: Colors.white,
                onTap: () => _launch('https://wa.me/${order.phone.replaceAll(RegExp(r'\D'), '')}')),
            _ContactBtn(label: '🗺 Google Maps', outline: const Color(0xFF4285F4), fg: const Color(0xFF4285F4),
                onTap: () => _launch('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent('${order.addr1}, Kuwait')}')),
            _ContactBtn(label: '🚗 Waze', outline: const Color(0xFF33CCFF), fg: const Color(0xFF33CCFF),
                onTap: () => _launch('https://waze.com/ul?q=${Uri.encodeComponent('${order.addr1}, Kuwait')}')),
          ],
        ),
        const SizedBox(height: 12),
        // Ask dispatcher
        GestureDetector(
          onTap: () => showWToast(context, '🆘 Dispatcher notified to call patient'),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 11),
            decoration: BoxDecoration(
              border: Border.all(color: WTheme.cloud, width: 1, style: BorderStyle.solid),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Center(child: Text('🆘 Need help reaching them? Ask dispatcher to call →',
                style: GoogleFonts.dmSans(color: WTheme.muted, fontSize: 12, fontWeight: FontWeight.w700))),
          ),
        ),
      ]),
    );
  }

  void _launch(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) launchUrl(uri);
  }
}

class _ContactBtn extends StatelessWidget {
  const _ContactBtn({required this.label, this.bg, this.outline, required this.fg, required this.onTap});
  final String label;
  final Color? bg, outline, fg;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      decoration: BoxDecoration(
        color: bg ?? Colors.white,
        border: outline != null ? Border.all(color: outline!, width: 1.5) : null,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(child: Text(label, style: GoogleFonts.dmSans(
          color: fg, fontWeight: FontWeight.w700, fontSize: 12))),
    ),
  );
}

// ── Total to collect card ──────────────────────────────────────
class _TotalCard extends StatelessWidget {
  const _TotalCard({required this.order});
  final Order order;

  @override
  Widget build(BuildContext context) {
    final delivery = order.deliveryFee ?? 1.500;
    final discount = order.discount ?? 0.0;
    final subtotal = order.total - delivery + discount;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: WTheme.navy.withOpacity(0.10), blurRadius: 30, offset: const Offset(0, 12))],
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('💰 TOTAL TO COLLECT', style: GoogleFonts.dmSans(
              fontSize: 11, fontWeight: FontWeight.w700, color: WTheme.muted, letterSpacing: 0.5)),
          PayChip(method: order.payMethod, paid: order.paid),
        ]),
        const SizedBox(height: 14),
        _TotalRow('Sub-total', subtotal),
        if (discount > 0)
          _TotalRow('🎁 Discount', -discount, color: WTheme.ok)
        else
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('🎁 DISCOUNT', style: GoogleFonts.dmSans(fontSize: 12, color: WTheme.muted, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
              Text('— no discount', style: GoogleFonts.dmSans(fontSize: 12, color: WTheme.muted, fontWeight: FontWeight.w600)),
            ]),
          ),
        _TotalRow('🛵 Delivery', delivery),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          decoration: BoxDecoration(
            gradient: order.paid ? null
                : const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [Color(0xFF023B60), Color(0xFF04527F)]),
            color: order.paid ? WTheme.ok.withOpacity(0.10) : null,
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text('TOTAL', style: GoogleFonts.dmSans(
                    color: order.paid ? WTheme.ok : Colors.white,
                    fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                RichText(text: TextSpan(children: [
                  TextSpan(text: order.total.toStringAsFixed(3),
                      style: GoogleFonts.dmSans(color: order.paid ? WTheme.ok : Colors.white,
                          fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                  TextSpan(text: ' KD', style: GoogleFonts.dmSans(
                      color: (order.paid ? WTheme.ok : Colors.white).withOpacity(0.7),
                      fontSize: 13, fontWeight: FontWeight.w600)),
                ])),
              ]),
        ),
      ]),
    );
  }
}

class _TotalRow extends StatelessWidget {
  const _TotalRow(this.label, this.amount, {this.color});
  final String label;
  final double amount;
  final Color? color;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label.toUpperCase(), style: GoogleFonts.dmSans(
          fontSize: 12, color: color ?? WTheme.muted,
          fontWeight: FontWeight.w700, letterSpacing: 0.5)),
      Text('${amount < 0 ? "− " : ""}${amount.abs().toStringAsFixed(3)} KD',
          style: GoogleFonts.dmSans(color: color ?? WTheme.navy,
              fontSize: 14, fontWeight: FontWeight.w700)),
    ]),
  );
}

// ── Big Payment Status ─────────────────────────────────────────
class _BigPaymentStatus extends StatelessWidget {
  const _BigPaymentStatus({required this.order});
  final Order order;

  @override
  Widget build(BuildContext context) {
    final isPaid = order.paid;
    final method = order.payMethod;
    final String label, sub, methodLabel, icon;
    final List<Color> gradColors;

    if (isPaid) {
      label = '✓ ALREADY PAID'; sub = 'No collection needed — just deliver';
      methodLabel = 'PAID'; icon = '✓';
      gradColors = [WTheme.ok, const Color(0xFF1A9C68)];
    } else if (method == PayMethod.knet) {
      label = '💳 COLLECT BY KNET'; sub = 'Use card terminal at door';
      methodLabel = 'KNET CARD'; icon = '💳';
      gradColors = [WTheme.sky, const Color(0xFF1577AC)];
    } else if (method == PayMethod.link) {
      label = '🔗 PAYMENT LINK SENT'; sub = 'Confirm patient paid before handover';
      methodLabel = 'LINK'; icon = '🔗';
      gradColors = [WTheme.ok, const Color(0xFF1A9C68)];
    } else {
      label = '💵 COLLECT CASH'; sub = 'Exact change preferred';
      methodLabel = 'CASH ON DELIVERY'; icon = '💵';
      gradColors = [WTheme.warn, const Color(0xFFC7800E)];
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: gradColors),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 32, offset: Offset(0, 14))],
      ),
      child: Stack(children: [
        Positioned(top: -10, right: -10,
            child: Text(icon, style: const TextStyle(fontSize: 90, color: Colors.white10))),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('PAYMENT STATUS', style: GoogleFonts.dmSans(
              color: Colors.white.withOpacity(0.85), fontSize: 10,
              fontWeight: FontWeight.w800, letterSpacing: 0.8)),
          const SizedBox(height: 6),
          Text(label, style: GoogleFonts.dmSans(
              color: Colors.white, fontSize: 24,
              fontWeight: FontWeight.w800, letterSpacing: -0.5, height: 1.15)),
          const SizedBox(height: 6),
          Text(sub, style: GoogleFonts.dmSans(
              color: Colors.white.withOpacity(0.9), fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.only(top: 12),
            decoration: BoxDecoration(border: Border(top: BorderSide(
                color: Colors.white.withOpacity(0.35), width: 1.5, style: BorderStyle.solid))),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center, children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(999)),
                    child: Text(methodLabel, style: GoogleFonts.dmSans(
                        color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.6)),
                  ),
                  RichText(text: TextSpan(children: [
                    TextSpan(text: order.total.toStringAsFixed(3), style: GoogleFonts.dmSans(
                        color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                    TextSpan(text: ' KD', style: GoogleFonts.dmSans(
                        color: Colors.white.withOpacity(0.75), fontSize: 12, fontWeight: FontWeight.w700)),
                  ])),
                ]),
          ),
        ]),
      ]),
    );
  }
}

// ── Building Photos Block ──────────────────────────────────────
class _BuildingPhotosBlock extends StatefulWidget {
  const _BuildingPhotosBlock({required this.order});
  final Order order;
  @override
  State<_BuildingPhotosBlock> createState() => _BuildingPhotosBlockState();
}

class _BuildingPhotosBlockState extends State<_BuildingPhotosBlock> {
  bool _capturing = false;
  final _noteCtrl = TextEditingController();
  final List<Map<String, String>> _photos = [];

  void _submit() => setState(() {
    _photos.add({'note': _noteCtrl.text.trim().isEmpty ? 'Building photo' : _noteCtrl.text.trim(), 'by': 'You'});
    _capturing = false;
    _noteCtrl.clear();
  });

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white,
        boxShadow: [BoxShadow(color: WTheme.navy.withOpacity(0.10), blurRadius: 30, offset: const Offset(0, 12))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text('🏢 BUILDING PHOTOS', style: GoogleFonts.dmSans(
            fontSize: 11, fontWeight: FontWeight.w700, color: WTheme.muted, letterSpacing: 0.5)),
        if (_photos.isNotEmpty) ...[
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(color: WTheme.ok.withOpacity(0.12), borderRadius: BorderRadius.circular(999)),
            child: Text('${_photos.length} ON FILE', style: GoogleFonts.dmSans(
                color: WTheme.ok, fontSize: 9, fontWeight: FontWeight.w800)),
          ),
        ],
      ]),
      const SizedBox(height: 10),
      if (_photos.isNotEmpty)
        SizedBox(height: 120, child: ListView.separated(
          scrollDirection: Axis.horizontal, itemCount: _photos.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) => Container(
            width: 110, padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: WTheme.blush, borderRadius: BorderRadius.circular(10),
                border: Border.all(color: WTheme.cloud, width: 1.5)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(height: 70, decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [WTheme.cloud, WTheme.aqua.withOpacity(0.20)]),
                  borderRadius: BorderRadius.circular(8)),
                  child: const Center(child: Text('📷', style: TextStyle(fontSize: 32)))),
              const SizedBox(height: 4),
              Text(_photos[i]['note']!, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.dmSans(fontSize: 10, fontWeight: FontWeight.w700, color: WTheme.navy)),
              Text('by ${_photos[i]['by']}', style: GoogleFonts.dmSans(fontSize: 9, color: WTheme.muted)),
            ]),
          ),
        ))
      else
        Container(
          width: double.infinity, margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: WTheme.blush, borderRadius: BorderRadius.circular(10),
              border: Border.all(color: WTheme.cloud)),
          child: Center(child: Text(
              'No photos yet — be the first to help future drivers find this building.',
              style: GoogleFonts.dmSans(fontSize: 12, color: WTheme.muted, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center)),
        ),
      if (_capturing)
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: WTheme.blush, borderRadius: BorderRadius.circular(12),
              border: Border.all(color: WTheme.aqua, width: 1.5)),
          child: Column(children: [
            Container(height: 140, width: double.infinity,
                decoration: BoxDecoration(color: WTheme.cloud, borderRadius: BorderRadius.circular(10)),
                child: const Center(child: Text('📷', style: TextStyle(fontSize: 40)))),
            const SizedBox(height: 10),
            TextField(controller: _noteCtrl,
                style: GoogleFonts.dmSans(fontSize: 12, color: WTheme.navy),
                decoration: InputDecoration(
                  hintText: "Add a quick note (e.g. 'beige building, blue door')",
                  hintStyle: GoogleFonts.dmSans(fontSize: 12, color: WTheme.muted),
                  filled: true, fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: WTheme.cloud)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: WTheme.cloud, width: 1.5)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                )),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: GestureDetector(onTap: () => setState(() => _capturing = false),
                  child: Container(padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(color: WTheme.cloud, borderRadius: BorderRadius.circular(10)),
                      child: Center(child: Text('CANCEL', style: GoogleFonts.dmSans(color: WTheme.navy, fontWeight: FontWeight.w800, fontSize: 12)))))),
              const SizedBox(width: 8),
              Expanded(flex: 2, child: GestureDetector(onTap: _submit,
                  child: Container(padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(color: WTheme.ok, borderRadius: BorderRadius.circular(10),
                          boxShadow: [BoxShadow(color: WTheme.ok.withOpacity(0.4), blurRadius: 14, offset: const Offset(0, 6))]),
                      child: Center(child: Text('✓ SAVE & SHARE WITH DRIVERS', style: GoogleFonts.dmSans(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)))))),
            ]),
          ]),
        )
      else
        GestureDetector(onTap: () => setState(() => _capturing = true),
            child: Container(
                width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: WTheme.aqua, width: 1.5, style: BorderStyle.solid)),
                child: Center(child: Text('📷 ADD BUILDING PHOTO', style: GoogleFonts.dmSans(
                    color: WTheme.sky, fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 0.4))))),
    ]),
  );
}

// ── Driver action bar (bottom swipe section) ──────────────────
class _DriverActionBar extends StatefulWidget {
  const _DriverActionBar({
    required this.order,
    required this.onTransitionState,
    required this.onArrive,
    required this.onMultiPickup,
  });
  final Order order;
  final void Function(String id, DriverState state) onTransitionState;
  final VoidCallback onArrive, onMultiPickup;

  @override
  State<_DriverActionBar> createState() => _DriverActionBarState();
}

class _DriverActionBarState extends State<_DriverActionBar> {
  void _transition(DriverState state) {
    widget.onTransitionState(widget.order.id, state);
  }

  @override
  Widget build(BuildContext context) {
    final ds = widget.order.driverState;

    // Done/failed — show status banner
    if (ds == DriverState.delivered || ds == DriverState.failed) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: (ds == DriverState.failed ? WTheme.err : WTheme.ok).withOpacity(0.10),
          border: Border.all(
              color: ds == DriverState.failed ? WTheme.err : WTheme.ok,
              width: 1.5, style: BorderStyle.solid),
        ),
        child: Center(child: Text(
          ds == DriverState.failed ? '🚫 Delivery failed' : '✓ Delivered — order complete',
          style: GoogleFonts.dmSans(
              color: ds == DriverState.failed ? WTheme.err : WTheme.ok,
              fontSize: 13, fontWeight: FontWeight.w700),
        )),
      );
    }

    final String stepLabel, swipeLabel;
    final Color swipeColor, labelColor;
    final VoidCallback onConfirm;

    switch (ds) {
      case DriverState.pending:
        stepLabel  = 'Step 1 of 4 · Heading to pharmacy';
        swipeLabel = widget.order.multiPharmacy
            ? "I'm on my way to first pharmacy"
            : "I'm on my way to pharmacy";
        swipeColor = WTheme.sky;
        labelColor = const Color(0xFF2A9BBC);
        onConfirm  = () { _transition(DriverState.collecting); };
      case DriverState.collecting:
        stepLabel  = 'Step 2 of 4 · Collecting from pharmacy';
        swipeLabel = widget.order.multiPharmacy
            ? 'Open pickup checklist'
            : 'Confirm items picked up';
        swipeColor = WTheme.aqua;
        labelColor = WTheme.aqua;
        onConfirm  = widget.order.multiPharmacy
            ? () => Future.microtask(widget.onMultiPickup)
            : () { _transition(DriverState.pickedUp); };
      case DriverState.pickedUp:
        stepLabel  = 'Step 3 of 4 · Items in hand — head to patient';
        swipeLabel = 'Heading to patient (open directions)';
        swipeColor = WTheme.rose;
        labelColor = WTheme.rose;
        onConfirm  = () { _transition(DriverState.onMyWay); };
      default: // onMyWay
        stepLabel  = 'Step 4 of 4 · On the way · Swipe at the door';
        swipeLabel = "I've arrived at patient";
        swipeColor = WTheme.aqua;
        labelColor = WTheme.aqua;
        onConfirm  = () => Future.microtask(widget.onArrive);
    }

    return Column(children: [
      Text(stepLabel.toUpperCase(), textAlign: TextAlign.center,
          style: GoogleFonts.dmSans(fontSize: 11, fontWeight: FontWeight.w800,
              color: labelColor, letterSpacing: 0.6)),
      const SizedBox(height: 8),
      SwipeToConfirm(label: swipeLabel, color: swipeColor, onConfirm: onConfirm),
    ]);
  }
}
